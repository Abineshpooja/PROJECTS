from django.db import models

class pay(models.Model):
    name=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    address=models.CharField(max_length=100)
    city=models.CharField(max_length=100)
    state=models.CharField(max_length=100)
    zip=models.IntegerField()
    nameoncard=models.CharField(max_length=100)
    creditcardnumber=models.IntegerField()
    exp_month=models.CharField(max_length=100)
    exp_year=models.IntegerField()
    cvv=models.IntegerField()
    


# Create your models here.